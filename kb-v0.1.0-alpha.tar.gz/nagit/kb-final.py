#!/usr/bin/env python3
# Name: Komiksowa baza - Comic Base v. 0.1 alpha 
# Inspiration: Inspired by old monitor Hercules. 
# Author: jms@data.pl , bofh@retro-technology.pl
# Enjoy!

import json
import os
from tkinter import (
    Tk, Frame, Label, Button, Entry, Text, Scrollbar, END, messagebox, filedialog, Toplevel, StringVar,
    CENTER, RIGHT, LEFT, Y, BOTH, VERTICAL, X
)
from tkinter.ttk import Treeview, Style
from PIL import Image, ImageTk

DB_FILE = "comics_db.json"
AUTHOR = "Autor programu: bofh@retro-technology.pl"


def load_db():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_db(data):
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


class ComicDatabaseApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Komiksowa Baza Danych")
        self.db = load_db()

        self.selected_index = None
        self.cover_photo = None

        self.cover_width = 300
        self.cover_height = 400

        self.root.configure(bg="black")

        self.style = Style()
        self.style.theme_use('clam')

        # Style Treeview with orange text and black background
        self.style.configure(
            "Treeview.Heading",
            font=("Arial", 11, "bold"),
            foreground="orange",
            background="black",
        )
        self.style.configure(
            "Treeview",
            font=("Arial", 10),
            foreground="orange",
            background="black",
            fieldbackground="black",
        )
        self.style.map(
            "Treeview",
            background=[("selected", "#FF6700")],
            foreground=[("selected", "black")],
        )

        # Variables for sorting and filtering state
        self.sort_column = None  # currently sorted column
        self.sort_reverse = False  # sort order: False=ascending, True=descending
        self.filter_list = None  # current filtered list or None if none applied

        self.create_widgets()
        self.populate_comics_table()

    def create_widgets(self):
        # Main frame
        self.main_frame = Frame(self.root, bg="black")
        self.main_frame.pack(fill=BOTH, expand=True, padx=10, pady=10)

        # Search frame
        search_frame = Frame(self.main_frame, bg="black")
        search_frame.pack(fill=X)

        lbl_search = Label(
            search_frame, text="Wyszukaj: ", fg="orange", bg="black"
        )
        lbl_search.pack(side=LEFT)

        self.search_var = StringVar()
        self.search_entry = Entry(
            search_frame,
            textvariable=self.search_var,
            fg="orange",
            bg="black",
            insertbackground="orange",
            highlightbackground="orange",
            highlightcolor="orange",
            highlightthickness=1,
        )
        self.search_entry.pack(side=LEFT, fill=X, expand=True, padx=(0, 10))
        self.search_entry.bind("<Return>", lambda e: self.search_comics())

        btn_search = Button(
            search_frame,
            text="Szukaj",
            command=self.search_comics,
            fg="black",
            bg="#FF6700",
            activebackground="#e65c00",
            activeforeground="black",
        )
        btn_search.pack(side=LEFT)

        btn_show_all = Button(
            search_frame,
            text="Pokaż wszystko",
            command=self.show_all_comics,
            fg="black",
            bg="#FF6700",
            activebackground="#e65c00",
            activeforeground="black",
        )
        btn_show_all.pack(side=LEFT, padx=(10, 0))

        # Table frame
        self.table_frame = Frame(self.main_frame, bg="black")
        self.table_frame.pack(fill=BOTH, expand=True, pady=(10, 10))

        columns = ("title", "author", "publisher", "year", "issue", "condition")
        self.tree = Treeview(
            self.table_frame,
            columns=columns,
            show="headings",
            selectmode="browse",
            style="Treeview",
        )

        # Define column headings with sort command attached
        for col, title in [
            ("title", "Tytuł"),
            ("author", "Autor/Rysownik"),
            ("publisher", "Wydawnictwo"),
            ("year", "Rok"),
            ("issue", "Nr zeszytu"),
            ("condition", "Stan"),
        ]:
            self.tree.heading(col, text=title, command=lambda c=col: self.sort_by_column(c))

        self.tree.column("title", anchor=CENTER, width=180)
        self.tree.column("author", anchor=CENTER, width=120)
        self.tree.column("publisher", anchor=CENTER, width=120)
        self.tree.column("year", anchor=CENTER, width=60)
        self.tree.column("issue", anchor=CENTER, width=80)
        self.tree.column("condition", anchor=CENTER, width=100)
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)

        scrollbar = Scrollbar(self.table_frame, orient=VERTICAL, command=self.tree.yview)
        scrollbar.pack(side=RIGHT, fill=Y)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.bind("<<TreeviewSelect>>", self.on_comic_select)

        # Details and cover frame
        self.details_frame = Frame(self.main_frame, relief="groove", borderwidth=2, bg="black")
        self.details_frame.pack(fill=BOTH, expand=True)

        self.cover_and_info_frame = Frame(self.details_frame, bg="black")
        self.cover_and_info_frame.pack(fill=BOTH, expand=True, padx=10, pady=10)

        # Fixed size container for cover to prevent resizing
        self.cover_container = Frame(
            self.cover_and_info_frame,
            width=self.cover_width,
            height=self.cover_height,
            bg="black",
            relief="solid",
            borderwidth=1,
        )
        self.cover_container.pack_propagate(False)
        self.cover_container.pack(side=LEFT, padx=10, pady=10)

        self.cover_label = Label(
            self.cover_container, text="Brak okładki", fg="orange", bg="black", anchor=CENTER
        )
        self.cover_label.pack(fill=BOTH, expand=True)

        # Info panel
        self.info_frame = Frame(self.cover_and_info_frame, bg="black")
        self.info_frame.pack(fill=BOTH, expand=True, side=LEFT, padx=10, pady=10)

        self.info_text = Text(
            self.info_frame,
            width=50,
            height=15,
            font=("Arial", 11),
            wrap="word",
            fg="orange",
            bg="black",
            insertbackground="orange",
            highlightbackground="orange",
            highlightcolor="orange",
            highlightthickness=1,
        )
        self.info_text.pack(fill=BOTH, expand=True)
        self.info_text.config(state="disabled")

        # Author label
        self.author_label = Label(
            self.details_frame, text=AUTHOR, fg="orange", bg="black", anchor="w"
        )
        self.author_label.pack(fill=X, padx=10, pady=(0, 5))

        # Buttons frame
        buttons_frame = Frame(self.details_frame, bg="black")
        buttons_frame.pack(fill=X, pady=(0, 10), padx=10)

        btn_params = dict(fg="black", bg="#FF6700", activebackground="#e65c00", activeforeground="black")

        Button(buttons_frame, text="Dodaj nowy komiks", command=self.add_comic, **btn_params).pack(side=LEFT, padx=5)
        self.edit_btn = Button(
            buttons_frame, text="Edytuj wybrany", command=self.edit_comic, state="disabled", **btn_params
        )
        self.edit_btn.pack(side=LEFT, padx=5)
        self.delete_btn = Button(
            buttons_frame, text="Usuń wybrany", command=self.delete_comic, state="disabled", **btn_params
        )
        self.delete_btn.pack(side=LEFT, padx=5)

        Button(buttons_frame, text="Wyjście", command=self.root.quit, **btn_params).pack(side=RIGHT, padx=5)

    def populate_comics_table(self, filter_list=None):
        self.tree.delete(*self.tree.get_children())

        # Use filter_list if provided else use self.filter_list else self.db
        if filter_list is not None:
            # If new filter is provided update stored filter_list
            self.filter_list = filter_list
        source = self.filter_list if self.filter_list is not None else self.db

        # If sorting is active, sort the source accordingly before displaying
        if self.sort_column:
            # Sort with key function that handles int for numeric columns and strings for others
            def sort_key(comic):
                val = comic.get(self.sort_column, "")
                # Use numeric sorting for year and issue columns if possible
                if self.sort_column in ("year", "issue"):
                    try:
                        return int(val)
                    except Exception:
                        return val.lower() if isinstance(val, str) else val
                return val.lower() if isinstance(val, str) else val

            source = sorted(source, key=sort_key, reverse=self.sort_reverse)

        for idx, comic in enumerate(source):
            self.tree.insert(
                "",
                END,
                iid=idx,
                values=(
                    comic.get("title", ""),
                    comic.get("author", ""),
                    comic.get("publisher", ""),
                    comic.get("year", ""),
                    comic.get("issue", ""),
                    comic.get("condition", ""),
                ),
            )
        self.clear_selection()

    def clear_selection(self):
        self.selected_index = None
        self.info_text.config(state="normal")
        self.info_text.delete(1.0, END)
        self.info_text.config(state="disabled")
        self.cover_label.config(image="", text="Brak okładki", fg="orange")
        self.cover_photo = None
        self.edit_btn.config(state="disabled")
        self.delete_btn.config(state="disabled")
        self.tree.selection_remove(self.tree.selection())

    def on_comic_select(self, event):
        selected = self.tree.selection()
        if not selected:
            self.clear_selection()
            return

        try:
            idx = int(selected[0])
        except Exception:
            self.clear_selection()
            return

        displayed_list = self.get_displayed_comic_list()
        if idx < 0 or idx >= len(displayed_list):
            self.clear_selection()
            return

        comic = displayed_list[idx]
        # Now determine the index of this comic in the original db to keep track for editing/deleting.
        try:
            original_index = self.db.index(comic)
        except ValueError:
            # Comic not found - maybe db changed, just clear selection
            self.clear_selection()
            return

        self.selected_index = original_index
        self.display_comic_details(comic)
        self.edit_btn.config(state="normal")
        self.delete_btn.config(state="normal")

    def get_displayed_comic_list(self):
        # Uses self.filter_list if set, else full db
        source = self.filter_list if self.filter_list is not None else self.db[:]

        # Apply sorting
        if self.sort_column:
            def sort_key(comic):
                val = comic.get(self.sort_column, "")
                if self.sort_column in ("year", "issue"):
                    try:
                        return int(val)
                    except Exception:
                        return val.lower() if isinstance(val, str) else val
                return val.lower() if isinstance(val, str) else val

            source.sort(key=sort_key, reverse=self.sort_reverse)

        return source

    def display_comic_details(self, comic):
        details_lines = [
            f"Tytuł: {comic.get('title', '')}",
            f"Autor/Rysownik: {comic.get('author', '')}",
            f"Wydawnictwo: {comic.get('publisher', '')}",
            f"Rok: {comic.get('year', '')}",
            f"Nr zeszytu: {comic.get('issue', '')}",
            f"Stan: {comic.get('condition', '')}",
        ]
        self.info_text.config(state="normal")
        self.info_text.delete(1.0, END)
        self.info_text.insert(END, "\n".join(details_lines))
        self.info_text.config(state="disabled")

        cover_path = comic.get("cover", "").strip()
        if cover_path and os.path.isfile(cover_path):
            try:
                img = Image.open(cover_path).convert("RGBA")
                target_w, target_h = self.cover_width, self.cover_height

                # Calculate aspect ratios
                img_ratio = img.width / img.height
                target_ratio = target_w / target_h

                if img_ratio > target_ratio:
                    # Image wider than target frame
                    new_w = target_w
                    new_h = int(target_w / img_ratio)
                else:
                    # Image taller than target frame
                    new_h = target_h
                    new_w = int(target_h * img_ratio)

                img = img.resize((new_w, new_h), Image.LANCZOS)

                # Create a black background
                background = Image.new("RGBA", (target_w, target_h), (0, 0, 0, 255))

                # Center the image on the background
                paste_x = (target_w - new_w) // 2
                paste_y = (target_h - new_h) // 2

                background.paste(img, (paste_x, paste_y), img)

                # Convert to PhotoImage and display
                self.cover_photo = ImageTk.PhotoImage(background.convert("RGB"))
                self.cover_label.config(image=self.cover_photo, text="")
            except Exception:
                self.cover_label.config(image="", text="Brak okładki", fg="orange")
                self.cover_photo = None
        else:
            self.cover_label.config(image="", text="Brak okładki", fg="orange")
            self.cover_photo = None

    def add_comic(self):
        ComicEditWindow(self.root, self, title="Dodawanie nowego komiksu")

    def edit_comic(self):
        if self.selected_index is None:
            messagebox.showerror("Błąd", "Nie wybrano komiksu do edycji.")
            return
        comic = self.db[self.selected_index]
        ComicEditWindow(
            self.root, self, comic=comic, index=self.selected_index, title="Edycja komiksu"
        )

    def delete_comic(self):
        if self.selected_index is None:
            messagebox.showerror("Błąd", "Nie wybrano komiksu do usunięcia.")
            return
        comic = self.db[self.selected_index]
        answer = messagebox.askyesno(
            "Potwierdzenie", f"Czy na pewno chcesz usunąć komiks:\n{comic.get('title', '')}?"
        )
        if answer:
            self.db.pop(self.selected_index)
            save_db(self.db)
            # After deletion clear filter to avoid inconsistencies
            self.filter_list = None
            self.populate_comics_table()
            messagebox.showinfo("Usunięto", "Komiks został usunięty.")

    def search_comics(self):
        query = self.search_var.get().strip().lower()
        if not query:
            self.filter_list = None
            self.populate_comics_table()
            return

        results = [
            comic
            for comic in self.db
            if any(
                query in str(comic.get(k, "")).lower()
                for k in ["title", "author", "publisher"]
            )
        ]

        if not results:
            messagebox.showinfo("Wynik wyszukiwania", "Brak wyników wyszukiwania.")
            self.filter_list = None
            self.populate_comics_table()
        else:
            self.filter_list = results
            self.populate_comics_table()

        self.clear_selection()

    def show_all_comics(self):
        self.search_var.set("")
        self.filter_list = None
        self.populate_comics_table()
        self.clear_selection()

    def sort_by_column(self, column):
        # If clicking on same column toggle sort order, else set ascending
        if self.sort_column == column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_column = column
            self.sort_reverse = False

        self.populate_comics_table()

        # Update heading texts to show sort indicators
        self.update_heading_sort_indicators()

    def update_heading_sort_indicators(self):
        columns = ("title", "author", "publisher", "year", "issue", "condition")
        for col in columns:
            text = {
                "title": "Tytuł",
                "author": "Autor/Rysownik",
                "publisher": "Wydawnictwo",
                "year": "Rok",
                "issue": "Nr zeszytu",
                "condition": "Stan",
            }[col]

            if col == self.sort_column:
                arrow = " ↓" if self.sort_reverse else " ↑"
                text += arrow
            self.tree.heading(col, text=text, command=lambda c=col: self.sort_by_column(c))


class ComicEditWindow:
    def __init__(self, parent, app, comic=None, index=None, title=""):
        self.top = Toplevel(parent)
        self.top.transient(parent)
        self.top.grab_set()
        self.top.title(title)
        self.app = app
        self.comic = comic
        self.index = index

        self.top.configure(bg="black")

        self.entries = {}

        self.build_ui()

        if comic:
            self.fill_fields()

    def build_ui(self):
        container = Frame(self.top, bg="black")
        container.pack(padx=10, pady=10, fill=BOTH, expand=True)

        labels = [
            "Tytuł",
            "Autor/Rysownik",
            "Wydawnictwo",
            "Rok wydania (np. 2023)",
            "Numer zeszytu",
            "Stan komiksu",
            "Ścieżka do okładki (opcjonalnie)",
        ]

        self.vars = {}
        for idx, label_text in enumerate(labels):
            lbl = Label(
                container, text=label_text + ": ", anchor="w", fg="orange", bg="black"
            )
            lbl.grid(row=idx, column=0, sticky="w", pady=5)

            var = StringVar()
            self.vars[label_text] = var
            entry = Entry(
                container,
                textvariable=var,
                width=50,
                fg="orange",
                bg="black",
                insertbackground="orange",
                highlightbackground="orange",
                highlightcolor="orange",
                highlightthickness=1,
            )
            entry.grid(row=idx, column=1, sticky="ew", pady=5)
            self.entries[label_text] = entry

            if label_text == "Ścieżka do okładki (opcjonalnie)":
                browse_btn = Button(
                    container,
                    text="Wybierz...",
                    command=self.browse_file,
                    fg="black",
                    bg="#FF6700",
                    activebackground="#e65c00",
                    activeforeground="black",
                )
                browse_btn.grid(row=idx, column=2, padx=(5, 0), pady=5)

        container.columnconfigure(1, weight=1)

        btn_frame = Frame(self.top, bg="black")
        btn_frame.pack(pady=10)

        btn_params = dict(fg="black", bg="#FF6700", activebackground="#e65c00", activeforeground="black")

        Button(btn_frame, text="Zapisz", command=self.save_comic, **btn_params).pack(side=LEFT, padx=5)
        Button(btn_frame, text="Anuluj", command=self.top.destroy, **btn_params).pack(side=LEFT, padx=5)

    def fill_fields(self):
        self.vars["Tytuł"].set(self.comic.get("title", ""))
        self.vars["Autor/Rysownik"].set(self.comic.get("author", ""))
        self.vars["Wydawnictwo"].set(self.comic.get("publisher", ""))
        self.vars["Rok wydania (np. 2023)"].set(self.comic.get("year", ""))
        self.vars["Numer zeszytu"].set(self.comic.get("issue", ""))
        self.vars["Stan komiksu"].set(self.comic.get("condition", ""))
        self.vars["Ścieżka do okładki (opcjonalnie)"].set(self.comic.get("cover", ""))

    def browse_file(self):
        filetypes = (
            ("Obrazki", "*.png *.jpg *.jpeg *.bmp *.gif"),
            ("Wszystkie pliki", "*.*"),
        )
        filename = filedialog.askopenfilename(title="Wybierz plik okładki", filetypes=filetypes)
        if filename:
            self.vars["Ścieżka do okładki (opcjonalnie)"].set(filename)

    def save_comic(self):
        title = self.vars["Tytuł"].get().strip()
        if not title:
            messagebox.showerror("Błąd", "Tytuł nie może być pusty.")
            return

        cover_path = self.vars["Ścieżka do okładki (opcjonalnie)"].get().strip()
        if cover_path and not os.path.isfile(cover_path):
            messagebox.showerror("Błąd", "Podana ścieżka do okładki jest niepoprawna.")
            return

        comic_data = {
            "title": title,
            "author": self.vars["Autor/Rysownik"].get().strip(),
            "publisher": self.vars["Wydawnictwo"].get().strip(),
            "year": self.vars["Rok wydania (np. 2023)"].get().strip(),
            "issue": self.vars["Numer zeszytu"].get().strip(),
            "condition": self.vars["Stan komiksu"].get().strip(),
            "cover": cover_path,
        }

        if self.comic is None:
            self.app.db.append(comic_data)
            messagebox.showinfo("Dodano", "Dodano nowy komiks do bazy.")
        else:
            self.app.db[self.index] = comic_data
            messagebox.showinfo("Zaktualizowano", "Zaktualizowano komiks.")

        save_db(self.app.db)

        # After adding/editing, clear filter to avoid inconsistencies
        self.app.filter_list = None
        self.app.populate_comics_table()
        self.top.destroy()


def main():
    root = Tk()
    root.minsize(800, 600)
    app = ComicDatabaseApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
